import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './home/admin.component';
import { EditComponent } from './edit/edit.component';
import { DetailsService } from '../details.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateComponent } from './create/create.component';
import { SharedModuleModule } from 'src/shared-module/shared-module.module';

@NgModule({
  declarations: [
    AdminComponent,
    EditComponent,
    CreateComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModuleModule
  ],
  exports: [
    AdminComponent,
    EditComponent,
    CreateComponent
  ],
  providers: [
    DetailsService
  ]
})
export class AdminModule { }
