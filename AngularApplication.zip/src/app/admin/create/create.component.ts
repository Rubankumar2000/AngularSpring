import { Component, OnInit } from '@angular/core';
import { DetailsService } from 'src/app/details.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  details: any;

  constructor(private detail: DetailsService) { }

  ngOnInit(): void {
    this.getDetails();
  }

  getDetails(){
    this.detail.getDetail().subscribe(data=>{
      this.details=data;
    })
  }

}
