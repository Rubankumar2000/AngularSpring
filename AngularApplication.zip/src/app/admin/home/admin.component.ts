import { state } from '@angular/animations';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DetailsService } from 'src/app/details.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  admin = 'Admin';

  details: any
  constructor(private detail: DetailsService,private router: Router) { }

  ngOnInit(): void {
    this.detail.getDetail().subscribe(data=>{
      console.log(data);
      this.details=data;
    })
  }

  editDetail(datas: any){
    this.router.navigate(['create'],{state: {data: datas}})
    this.details=datas;
  }

  goToCreate(){
    this.router.navigate(['create']);
  }

  goToHome(){
    this.router.navigate(['home']);
  }

}
