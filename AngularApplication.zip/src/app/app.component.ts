import { Component } from '@angular/core';
import { DetailsService } from './details.service';
import { LoadingService } from './loading.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularApplication';

  isLoader$ = this.loading.isLoader$

  constructor(private detail: DetailsService,private loading: LoadingService){}
  // userLoggedIn = true;
  // detail = "This is for custom component from app component"
}
