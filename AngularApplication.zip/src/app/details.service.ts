import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DetailsService {
  userId: any;

  constructor(private http: HttpClient) { }

  url = 'https://jsonplaceholder.typicode.com/posts/';

  getDetail(){
    return this.http.get(this.url);
  }
  updateDetail(data: any) {
    return this.http.put(this.url+data.id,data);
  }
  // getDetailById(id: any) {
  //   return this.http.get(this.url+id);
  // }
}
