import { style } from '@angular/animations';
import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DetailsService } from 'src/app/details.service';
import { LoadingService } from 'src/app/loading.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  details: any
  signupForm!: FormGroup;
  required = false;
  constructor(private detail: DetailsService,
    private el: ElementRef,
    private fb: FormBuilder,private router: Router,
    public loading: LoadingService) {
      this.details = history.state.data;

      this.signupForm = this.fb.group({
        userId: [this.details?this.details.userId:"",[Validators.required]],
        id: [this.details?this.details.id:"",[Validators.required]],
        title: [this.details?this.details.title:"",[Validators.required]],
        body: [this.details?this.details.body:"",[Validators.required, Validators.maxLength(255)]]
      })  
     }

  ngOnInit(): void {
    console.log(this.details)
  }
  
  get userId(){
    return this.signupForm.get('userId');
  }
  get id(){
    return this.signupForm.get('id');
  }
  get title(){
    return this.signupForm.get('title');
  }
  get body(){
    return this.signupForm.get('body');
  }


  updateDetail(data: any){
    console.log('update '+data);
    const invalidControl = this.el.nativeElement.querySelector('.ng-invalid');
      if (invalidControl) {
        invalidControl.focus();  
      }
    if(this.signupForm.invalid){
      this.required = true;
      return this.signupForm.value;
    }
    else if(this.signupForm.valid){
      this.required = false;
      this.detail.updateDetail(data).subscribe((datas: any)=>{
        console.log(datas);
      })
    }
  }

  goBack(){
    this.router.navigate(['home']);
  }

}
