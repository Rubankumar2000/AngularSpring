import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateComponent } from '../home/create/create.component';
import { HomeComponent } from './home/home.component';
import { SaveComponent } from './save/save.component';

const routes: Routes = [
    {path: 'home', component: HomeComponent},
    {path: 'save', component: SaveComponent},
    {path: 'create', component: CreateComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
