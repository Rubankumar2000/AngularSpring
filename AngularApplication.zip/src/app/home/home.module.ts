import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { SaveComponent } from './save/save.component';
import { CreateComponent } from './create/create.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { InterceptService } from '../interceptor/intercept.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LoadingService } from '../loading.service';
import { SharedModuleModule } from 'src/shared-module/shared-module.module';

@NgModule({
  declarations: [
    HomeComponent,
    SaveComponent,
    CreateComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    SharedModuleModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptService,
      multi: true
    }
  ]
})
export class HomeModule { }
