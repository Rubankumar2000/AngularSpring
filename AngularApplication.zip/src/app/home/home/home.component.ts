import { Component, createComponent, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { DetailsService } from 'src/app/details.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  details: any;

  home = 'Home';

  constructor(private detail: DetailsService,private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.detail.getDetail().subscribe(data => {
      this.details = data;
    })
  }

  onCall(){
  }
  editDetail(datas: any){
    // this.route.snapshot.params['id'];
    this.router.navigate(['create'],{state: {data: datas}});
      console.log(datas);
  }
  
  goToCreate(){
    this.router.navigate(['create']);
  }

  goToAdmin(){
    this.router.navigate(['admin']);
  }

}
