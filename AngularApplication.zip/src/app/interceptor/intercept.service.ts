import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, Observable, tap } from 'rxjs';
import { LoadingService } from '../loading.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptService implements HttpInterceptor {

  constructor(public loading: LoadingService) { }
  
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.loading.show();
    console.log('interceptor',req);
    const newReq = req.clone({
      setHeaders: {'Rubankumar': 'Hemnath'}})
      return next.handle(newReq).pipe(
        finalize(() => {
          this.loading.hide();
        }),
        tap((result)=>{
          console.log('success',result);
        },(error)=>{
          console.log('error',error);
        })
      );
  }
}
