import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom',
  templateUrl: './custom.component.html',
  styleUrls: ['./custom.component.css']
})
export class CustomComponent implements OnInit {

  @Input() name: any;

  constructor() { }

  ngOnInit(): void {
  }

}
