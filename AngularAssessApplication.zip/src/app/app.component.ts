import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {FormBuilder} from '@angular/forms';
import { customValidator } from './shared/custom.validators';
import { ViewServiceService } from './view-service.service';
import { ViewModule } from './view/view.module';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private fb: FormBuilder,private getService: ViewServiceService){}
  ngOnInit(): void {
    this.getService.postConfig(this.registrationForm).subscribe(data =>{
      console.log(data);
    });
  }
  registrationForm = this.fb.group({
    userName: ['',[Validators.required,Validators.minLength(3)],customValidator],
    password: [''],
    confirmPassword:[''],
    address: this.fb.group({
      city: [''],
      state:[''],
      postalCode: ['']
    })    
  })
  
  // registrationForm = new FormGroup({
  //   userName: new FormControl(''),
  //   password: new FormControl(''),
  //   confirmPassword: new FormControl(''),
  //   address: new FormGroup({
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     postalCode: new FormControl('')
  //   })
  // })
  loadData(){
    this.registrationForm.setValue({
    userName: 'Ruban',
    password: 'test',
    confirmPassword: 'test',
    address:({
    city: 'Erode',
    state: 'TamilNadu',
    postalCode: '638056'
  })
  })
  console.log(this.registrationForm);
}
registrationSuccess(){
  console.log(this.registrationForm.value);
}

}
