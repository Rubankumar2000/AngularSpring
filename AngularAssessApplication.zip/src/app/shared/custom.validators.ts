import { AbstractControl } from "@angular/forms";

export function customValidator(control: AbstractControl): {[key:string]: any} | null{
    const custom = /admin/.test(control.value);
    return custom ? {'customValid': {value: control.value}} : null;
    
}