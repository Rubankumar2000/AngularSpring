import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DetailService } from './detail.service';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap'
import {FormsModule} from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'app';

  details: any;
  idDetail: any;
  constructor(
    private detail: DetailService,private func: NgbModal
  ) {}

  //try instead of <ng-template>
  @ViewChild('myTestComp')
  myTestComp!: AppComponent;
    ngAfterViewInit(){
      
    }

  ngOnInit(): void {
    this.detail.getDetails().subscribe((data) => {
      this.details = data;
      console.log(this.details);
      
    })
  }

  // update(id: number) {
  //   this.detail.getDetailById(id).subscribe((data) => {
  //     this.idDetail = data;
  //     console.log(this.idDetail);
  //   });
  // }

  updateDetail(content: any){
    this.func.open(content,{size: 'md'})
  }
  update(data: any) {
    this.idDetail = data;
    };

}
