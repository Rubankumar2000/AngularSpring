import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmplyeeDetailsComponent } from './emplyee-details/emplyee-details.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';

const routes: Routes = [
  {path: 'getAll', component: EmployeeListComponent},
  {path: 'save',component: CreateEmployeeComponent},
  {path: '',redirectTo:'getAll',pathMatch: 'full'},
  {path: 'update/:id', component: UpdateEmployeeComponent},
  {path: 'view/:id',component: EmplyeeDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
