import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
  }

  saveEmployee(){
    this.employeeService.createEmployee(this.employee).subscribe((data: any) => {
      console.log(data);
      this.goToEmployee(); 
    },
      (    error: any) => console.error(error));
  }

  goToEmployee(){
    this.router.navigate(['/getAll']);
  }
  onSubmit(){
    const email = document.getElementById('email');
    console.log(email);
    console.log(this.employee);
    this.saveEmployee();
  }

  // registrationForm = this.fb.group({
  //   firstName: ['',[Validators.required,Validators.minLength(3)]],
  //   lastName: ['',[Validators.required,Validators.minLength(1)]],
  //   email: ['',Validators.required]
  // })
}
