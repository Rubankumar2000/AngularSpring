import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SweetAlertOptions } from 'sweetalert2';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees: Employee[] = [];
  constructor(private employeeService: EmployeeService,private router: Router) { }
  ngOnInit(): void {
    this.getEmployees();
  }
  private getEmployees(){
    console.log('Get All method')
    this.employeeService.getEmployeeList().subscribe((data: Employee[]) => {
      this.employees=data;
    })
  }
updateEmployee(id: any){
  this.router.navigate(['update',id]);
}
deleteEmployee(id: any){
  if(confirm('Are you sure, do you want to delete this record!'))
  {
    this.employeeService.deleteEmployee(id).subscribe(data =>{
    console.log(data);
    this.getEmployees();
  })
}
}

viewEmplyee(id: any){
  this.router.navigate(['view',id]);
}
}
