import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private url='http://localhost:8080/employees/';

  constructor(private httpClient: HttpClient) { }

  getEmployeeList(): any{
    return this.httpClient.get(this.url+"getAll");
  }

  createEmployee(employee: Employee): any{
    return this.httpClient.post(this.url+'save',employee);
  }

  getEmployeeById(id: any): any{
    return this.httpClient.get(this.url+'get/'+id);
  }

  updateEmployee(id: any,employee: Employee): any{
    return this.httpClient.put(this.url+'update/'+id,employee);
  }

  deleteEmployee(id: any){
    return this.httpClient.delete(this.url+'delete/'+id);
  }

  viewemployee(id: any): any{
    return this.httpClient.get(this.url+'get/'+id);
  }
}
