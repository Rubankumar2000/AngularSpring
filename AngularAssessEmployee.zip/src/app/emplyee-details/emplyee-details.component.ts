import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-emplyee-details',
  templateUrl: './emplyee-details.component.html',
  styleUrls: ['./emplyee-details.component.css']
})
export class EmplyeeDetailsComponent implements OnInit {
  
  id: any;
  employee: Employee = new Employee;
  constructor(private emplyeeService: EmployeeService,private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.emplyeeService.viewemployee(this.id).subscribe( (data: any) =>{
      this.employee=data;
    },
    (error:any) => console.log(error));
  }
  getEmployee(){
    this.router.navigate(['getAll']);
  }

}
