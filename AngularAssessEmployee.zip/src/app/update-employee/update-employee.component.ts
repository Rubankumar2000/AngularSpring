import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  id: any;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.employeeService.getEmployeeById(this.id).subscribe((data: any) =>{
      this.employee=data;
    },
      (    error: any) =>console.log(error));
  }

  onSubmit(){
    
  this.employeeService.updateEmployee(this.id,this.employee).subscribe((data: any) =>{
    Swal.fire({
      title: 'Success!',
      text: 'Saved successfuly',
      icon: 'success',
      toast: false,
      allowOutsideClick: false
  })
  }).then(() =>{
    this.goToEmployeeList();
  })
}

  getEmployee(){
    this.router.navigate(['getAll'])
  }

  goToEmployeeList() {
    this.router.navigate(['getAll']);
  }

  loadSpinner = false;
  loadData(){
    this.spinner.show();
    setTimeout(() => {
      this.goToEmployeeList();
      this.spinner.hide();
    }, 5000);

  }
}

