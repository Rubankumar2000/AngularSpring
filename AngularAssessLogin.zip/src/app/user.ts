export class User {
    constructor(
        public name: String,
        public email: String,
        public phone: Number,
        public topic: String,
        public timePreference: String,
        public subscribe: boolean
    ){}
}
