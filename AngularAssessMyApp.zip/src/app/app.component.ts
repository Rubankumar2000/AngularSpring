import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  //name = 'This is my CSK App';
  values: boolean=false;
  
 value = [
   {
     image: "http://localhost:4200/assets/images/Chennai_Super_Kings_Logo.png",
     name: "CSK",
     captain: "MS Dhoni",
     position: 9,
     Description: "Chennai Super Kings (CSK) are a franchise cricket team based in Chennai, Tamil Nadu, India. They play in the Indian Premier League (IPL). Founded in 2008, the team plays its home matches at the M. A. Chidambaram Stadium in Chennai."
   },
   {
    image: "http://localhost:4200/assets/images/MI.webp",
     name: "MI",
     captain: "Rohit Sharma",
     position: 10,
     Description: "Mumbai Indians are a franchise cricket team based in Mumbai, Maharashtra, that competes in the Indian Premier League. Founded in 2008, the team is owned by India's biggest conglomerate, Reliance Industries, through its 100% subsidiary IndiaWin Sports."
   },
   {
    image: "http://localhost:4200/assets/images/punjab.png",
     name: "PK",
     captain: "Mayank Agarwal",
     position: 7,
     Description: "Punjab Kings (PBKS) are a franchise cricket team based in Mohali, Punjab, that plays in the Indian Premier League (IPL). Established in 2008 as the Kings XI Punjab (KXIP), the franchise is jointly owned by Mohit Burman, Ness Wadia, Preity Zinta and Karan Paul. The team plays its home matches at the PCA Stadium, Mohali."
   },
   {
     image: "http://localhost:4200/assets/images/kkr.jpg",
     name: "KKR",
     captain: "Shreyas Iyer",
     position: 8,
     Description: "Kolkata Knight Riders (KKR) are a franchise cricket team representing the city of Kolkata in the Indian Premier League. The franchise is owned by Bollywood actor Shah Rukh Khan, actress Juhi Chawla and her spouse Jay Mehta. The Knight Riders play at the iconic Eden Gardens stadium."
   },
   {
     image: "http://localhost:4200/assets/images/rcb.webp",
     name: "RCB",
     captain: "Faf Du Plesis",
     position: 5,
     Description: "Royal Challengers Bangalore (often abbreviated as RCB) are a franchise cricket team based in Bangalore, Karnataka, that plays in the Indian Premier League (IPL). It was founded in 2008 by United Spirits and named after the company's liquor brand Royal Challenge."
   }];


  ngOnInit(): void {
    
  }
  show(id: Number) {
    if(id===0) {
      this.values=true;
    }
    else if(id===1) {
      this.values=true;
    }
    else if(id===2) {
      this.values=true;
    }
    else if(id===3) {
      this.values=true;
    }
    else if(id===4) {
      this.values=true;
    }
  }
  hide() {
    this.values=false;
  }
}
