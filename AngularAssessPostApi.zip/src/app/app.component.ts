import { Component, OnInit } from '@angular/core';
import { DetailService } from './detail.service';
import { FormBuilder, FormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  details: any;
  constructor(private router: Router,private detail: DetailService,private fb: FormBuilder){}
  ngOnInit(): void {
  }

    registerForm = this.fb.group({
      userId: ['',[Validators.required]],
      title: [''],
      body: ['']
    })
  onSubmit(){
    console.log(this.details.name);
    this.saveDetail();
  }

  saveDetail(){
    this.detail.createDetail(this.detail).subscribe((data: any) =>{
      console.log(data);
    }
  )}
}
