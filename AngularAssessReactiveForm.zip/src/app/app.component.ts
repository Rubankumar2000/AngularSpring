import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms'
import { ReactiveValidator } from './reactive';
import { ReactiveServiceService } from './reactive-service.service';
// import { ReactiveValidator } from './reactive';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'app';
  @ViewChild('addressRef') addrRef!: ElementRef
  
  ngAfterViewInit(){
    this.addrRef.nativeElement.focus();
  }

  countries = ['Afganistan','Brazil','Canada','Egypt','German','France','Hungary','India','Jamaica','Kenya','Laos','Mexico','Nepal','Oman','Pakistan','Qatar','Russia','Spain','Thailand','USA','Vietnam','Yeman','Zambia']

  constructor(private fb: FormBuilder,private reactiveService: ReactiveServiceService){}

  get email(){
    return this.registerForm.get('email');
  }
  get pass(){
    return this.registerForm.get('pass');
  }
  get address(){
    return this.registerForm.get('address');
  }
  get dob(){
    return this.registerForm.get('dob');
  }
  get country(){
    return this.registerForm.get('country');
  }
  get phone(){
    return this.registerForm.get('phone');
  }
  get privacy(){
    return this.registerForm.get('privacy');
  }

  registerForm = this.fb.group({
    email: ['',[Validators.required,Validators.email]],
    pass: ['',[Validators.required,Validators.pattern('^(?=[^a-z]*[a-z])(?=\\D*\\d)[A-Za-z\\d$%@#£€*?&]{8,}$')]],
    address: ['',[Validators.required]],
    dob: ['',[Validators.required]],
    country: ['',[Validators.required,ReactiveValidator.validate]],
    phone: ['',[Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
    privacy: [false,[Validators.requiredTrue]]
  })

  selection(e: any){
    console.log(this.registerForm.get('country')?.value);
    let value = e.target.value;   
    console.log(value);
    this.registerForm.controls['country'].setValue(value);
  }
  onSubmit(){
    if(this.registerForm.valid){
      console.log(this.registerForm.value);
      
      this.reactiveService.postDetail(this.registerForm.value).subscribe(data =>{
        console.log(data);
      },
      errors =>console.log(errors))
    }
    else{
      this.registerForm.updateValueAndValidity();
      console.log("else");
    }
    console.log(this.registerForm.updateValueAndValidity());
  }

  


  // registerForm = new FormGroup({
  //   email: new FormControl('',[Validators.required,Validators.email]),
  //   pass: new FormControl('',[Validators.required]),
  //   address: new FormControl('',[Validators.required]),
  //   dob: new FormControl('',[Validators.required]),
  //   phone: new FormControl('',[Validators.required]),
  //   state: new FormControl('',[Validators.required]),
  //   country: new FormControl('',[Validators.required]),
  // })
}
