import { ReactiveValidator } from './reactive';

describe('Reactive', () => {
  it('should create an instance', () => {
    expect(new ReactiveValidator()).toBeTruthy();
  });
});
