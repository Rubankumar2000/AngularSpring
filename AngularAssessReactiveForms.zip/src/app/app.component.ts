import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forbiddenValidator } from './shared/username.validators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // title = 'Reactive-forms';

  get fc(){
    return this.registrationForm.controls;
  }

  mustMatch(formControlName: any,matchControlName: any){
    return(formGroup: FormGroup)=>{
      const formControl = formGroup.controls[formControlName]
      const matchControl =  formGroup.controls[matchControlName]
      if (matchControl.errors && !matchControl.errors['mustMatch']) {
        // return if another validator has already found an error on the matchingControl
        return;
      }
      if(matchControl.value !== formControl.value){
        matchControl.setErrors({mustMatch:true});
      }
      else{
        matchControl.setErrors(null);
      }
    }

  }

  constructor(private fb: FormBuilder) {}
  registrationForm = this.fb.group({
    username: ['', [Validators.required,Validators.minLength(3),forbiddenValidator(/admin/)]],
    email: ['',[Validators.required,Validators.pattern('[a-z0-9.@]*')]],
    password: ['',[Validators.required,Validators.minLength(8),Validators.maxLength(15),Validators.pattern('[A-Za-z0-9.@!#$%^&*/]*')]],
    confirmPassword: ['',[Validators.required]],
    address: this.fb.group({
      city: ['',[Validators.required]],
      state: ['',[Validators.required]],
      postalCode: ['',[Validators.required,Validators.minLength(6),Validators.maxLength(6),Validators.pattern('[0-9]*')]]
    })
  },
  {
    validators: this.mustMatch('password','confirmPassword')
  });

 
  // registrationForm = new FormGroup({
  //   username: new FormControl(''),
  //   password: new FormControl(''),
  //   confirmPassword: new FormControl(''),
  //   address: new FormGroup({
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     postalCode: new FormControl('')
  //   })
  // });
  //<-------------setValue is used to set value to all the formcontrol field--------------->
  loadApiData(){
    this.registrationForm.setValue({
      username: 'Ruban',
      password: 'Test12',
      confirmPassword: 'Test12',
      address: {
        city: 'City',
        state: 'State',
        postalCode: '123455'
      }
    })
  }


                  // <---------- patchValue method is used patch for few of form controls------------->
  // loadApiData(){
  //   this.registrationForm.patchValue({
  //     username: 'Ruban',
  //     password: 'Test12',
  //     confirmPassword: 'Test12'
  //   })
  // }
}
