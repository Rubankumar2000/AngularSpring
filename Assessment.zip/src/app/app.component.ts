import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // employees = new  FormGroup({
  //   employeeName: new FormControl(''),
  //   employeeEmail: new FormControl(''),
  //   designation: new FormControl(''),
  //   status: new FormControl('')
  // })
  employee = [{
    employeeName: "John",
    employeeEmail: "John@prodian.co.in",
    designation: "Frontend",
    status: "inactive",
  },
  {
    employeeName: "Mark",
    employeeEmail: "mark@prodian.co.in",
    designation: "Frontend",
    status: "active",
  },{
    employeeName: "Bill",
    employeeEmail: "bill@prodian.co.in",
    designation: "Backend",
    status: "active",
  }]
  //   {
  //   employeeName : "Mark",
  //   employeeEmail : "Mark@prodian.co.in",
  //   designation : "Frontend",
  //   status : "active"
  //   },
  //   {
  //   employeeName : "Bill",
  //   employeeEmail : "Bill@prodian.co.in",
  //   designation : "Backend",
  //   status : "active"
  //   }
    
    
    
}

