function myfunction(){
    const list = document.getElementById("login-form")
    list.addEventListener('submit', e => {
      e.preventDefault();
      const forms = {};
      forms['name'] = document.getElementById('name').value;
      forms['email'] = document.getElementById('email').value;
      forms['age'] = document.getElementById('age').value;
      forms['dept'] = document.getElementById('dept').value;
      forms['url'] = document.getElementById('url').value;
      forms['gender'] = document.getElementsByName('gender')
            for(i=0;i<forms['gender'].length;i++) {
              if(forms['gender'][i].checked)
              document.getElementById('mgender').innerHTML=forms['gender'][i].value;
            }
      forms['comments'] = document.getElementById('comments').value;
      console.log()
      console.log(forms)
      console.log();
      document.getElementById('mname').innerHTML = forms['name'];
      document.getElementById('memail').innerHTML = forms['email'];
      document.getElementById('mage').innerHTML = forms['age'];
      document.getElementById('mdept').innerHTML = forms['dept'];
      document.getElementById('mcomments').innerHTML = forms['comments'];
      //document.getElementById('mgender').innerHTML=rate_value;
      document.getElementById('murl').innerHTML = forms['url'];

      // document.getElementById('memail').textContent=email;
      // console.log(memail)


      // console.log(email);
      // console.log(age);
      // console.log(dept);
      // console.log(url);
      // //console.log(gender);
      // console.log(comment);
    })
}