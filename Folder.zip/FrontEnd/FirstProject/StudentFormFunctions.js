// function onFormSubmit() {
//     var formData = readFormData();
//     insertNewRecord(formData);
// }

// function readFormData() {
//     var formData = {};
//     formData["sno"] = document.getElementById("sno").value;
//     formData["studentName"] = document.getElementById("studentName").value;
//     formData["dob"] = document.getElementById("dob").value;
//     formData["age"] = document.getElementById("age").value;
//     formData["studentID"] = document.getElementById("studentID").value;
//     formData["doj"] = document.getElementById("doj").value;
//     formData["createdAt"] = document.getElementById("createdAt").value;
//     formData["updatedAt"] = document.getElementById("updatedAt").value;
//     return formData;
// }

// function insertNewRecord(data) {
//     var table = document.getElementById("studentList").getElementsByTagName('tbody')[0];
//     var newRow = table.insertRow(table.length);
//     cell1=newRow.insertCell(0);
//     cell1.innerHTML=data.sno;
//     cell2=newRow.insertCell(1);
//     cell2.innerHTML=data.studentName;
//     cell3=newRow.insertCell(2);
//     cell3.innerHTML=data.dob;
//     cell4=newRow.insertCell(3);
//     cell4.innerHTML=data.age;
//     cell5=newRow.insertCell(4);
//     cell5.innerHTML=data.studentID;
//     cell6=newRow.insertCell(5);
//     cell6.innerHTML=data.doj;
//     cell7=newRow.insertCell(6);
//     cell7.innerHTML=data.createdAt;
//     cell8=newRow.insertCell(7);
//     cell8.innerHTML=data.updatedAt;
//     cell9=newRow.insertCell(8);
//     cell9.innerHTML=`<a>View</a><a>Delete</a>`;
// }



// fetch(url).then(res => res.json()).then(data => rendorPosts(data));

// const promise = fetch(url,{
//     method: "GET", 
// })

// promise.then(function(res) {
//     if(res.status===200) return res.json();
//     else throw new Error("Something failed..");
// }).then(function(data) {
//     console.log(data);
//     console.log(data[0]);
// }).catch(function(err){
//     console.log(err.message);
// });
const studentList=document.querySelector('table_body');
const output='';
const url="http://localhost:8080/employees/all";
fetch(url)
.then(res => res.json())
.then(data => {
    data.forEach(post => {
        output +=  `<td>${data.eID}</td>
                            <td>${data.eName}</td>
                    `; 
    });
    studentList.innerHTML=output;
})
// const xhr=new XMLHttpRequest();
// xhr.onload=function() {
//     if(xhr.status===200) {
//         console.log(xhr);
//         // const data = JSON.parse(xhr.response);
//         // console.log(data);
//     }
//     else{
//         console.log("something wrong");
//     }
// };
// xhr.open("GET",url);
// xhr.send();