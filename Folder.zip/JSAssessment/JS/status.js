var book = [   
    {
    title: 'Bill Gates',
    author: 'The Road Ahead',
    readingStatus: true
    },
    {
    title: 'Steve Jobs',
    author: 'Walter Isaacson',
    readingStatus: true
    },
    {
    title: 'Mockingjay: The Final Book of The Hunger Games',
    author: 'Suzanne Collins',
    readingStatus: false
    }
];

console.log(book)
// let btn = document.getElementById('btn');

for(i=0;i<book.length;i++){
    if(book[i].readingStatus===true){
        console.log('Already Read '+book[i].title+' by '+book[i].author);
    }
    else{
        console.log('Not Read '+book[i].title+' : '+book[i].author);
    }
}


// console.log(book.values('title'));
// btn.addEventListener('click', ()=>{
//     for(i=0;i<book.length;i++){
//     if(book[i].readingStatus === true){
//         console.log(book[i].readingStatus);
//     }}
// })