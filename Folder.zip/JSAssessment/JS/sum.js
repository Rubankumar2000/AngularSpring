var a = 10;
var b = 20;
if(a === b){
    console.log(a + a + a);
}
else{
    console.log(a+b);
}

// var a = document.getElementById('a');
// var b = document.getElementById('b');
// let btn = document.getElementById('btn');
// btn.addEventListener('click',() => {
//     var n=a.value
// console.log(a.value);

//     if(a.value===b.value){
//         console.log(n + n + n);
//     }
//     else{
//         console.log(a.value+b.value);
//     }
// })