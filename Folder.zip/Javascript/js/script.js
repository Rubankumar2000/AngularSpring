// console.table({fname: "Ruban",age: 22});
// console.time("startTime");
// for(i=0;i<10;i++){
//     // setTimeout(console.log(i),1000);
//     console.log(i)
// }
// console.timeEnd("startTime");


// document.getElementById("value").innerHTML = document.getElementById("input").value;

// alert("window")
// console.log(window);
// let input = document.getElementById("input");
// console.log(input.value);
// input.style.borderColor="Red"
// document.addEventListener("click",(e)=>{
//     e.preventDefault();
//     console.log(input.value);
//     document.getElementById("value").innerHTML = document.getElementById("input").value;
// })

function mouseFunc(){
    console.log("Mouse Over");
}
function clickFunc(){
    console.log("Click");
}

const input = document.getElementById("input");
input.onmouseover=mouseFunc;
input.onclick=clickFunc;
input.addEventListener("click",clickFunc);
input.addEventListener("mouseover",mouseFunc)